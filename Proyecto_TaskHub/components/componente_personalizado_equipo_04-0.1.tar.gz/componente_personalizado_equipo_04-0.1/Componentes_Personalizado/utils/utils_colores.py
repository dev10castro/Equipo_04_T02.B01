BLACK = "#000000"            # Negro
LIGHT_GREEN = "#D9F5DA"       # Verde claro
YELLOW_ORANGE = "#FECF49"     # Naranja amarillento
WHITE = "#FFFFFF"             # Blanco
CORAL = "#f2784b"             # Naranja coral
