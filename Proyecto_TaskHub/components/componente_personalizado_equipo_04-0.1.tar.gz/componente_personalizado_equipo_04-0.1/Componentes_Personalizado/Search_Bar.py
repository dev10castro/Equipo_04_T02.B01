
from PySide6.QtWidgets import QLineEdit

class Search_Bar(QLineEdit):
    def __init__(self):
        super().__init__()
        self.leText = QLineEdit()

        # Ajustamos la fuente:
        font = self.font()
        font.setFamily("Calibri")
        font.setPointSize(20)
        self.setFont(font)
        self.setStyleSheet("border: 2px solid #f2784b;"
                                  "border-radius:5px;")

