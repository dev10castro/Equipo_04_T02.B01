import os

from PySide6.QtWidgets import QPushButton
from PySide6.QtGui import QPalette, QColor, QIcon
from PySide6.QtCore import Signal, QSize
from .utils import utils_colores as colores

class Button_Search(QPushButton):

    signal_presionado = Signal()


    def __init__(
        self,
        text="Buscar",
        font_family="Calibri",
        font_size=20,
        font_color=colores.BLACK,
        bg_color=colores.CORAL,
        pressed_color=colores.YELLOW_ORANGE,
        border_radius=5,
        icon="search.png",
        parent=None,
    ):
        super().__init__(text,parent)

        self.bg_color = QColor(bg_color)
        self.setFontProperties(font_family, font_size)
        self.updateBackgroundColor(self.bg_color)

        # Verifica si la ruta del icono es correcta
        icon_path = icon
        if not os.path.exists(icon_path):
            print(f"Error: No se encontró el archivo en la ruta {icon_path}")
        else:
            # Cargar el icono SVG directamente usando QIcon
            icono = QIcon(icon_path)
            self.setIcon(icono)
            self.setIconSize(QSize(24, 24))  # Ajusta el tamaño del icono según sea necesario


    def setFontProperties(self, family, size):
        """
        Configura la fuente del botón.
        :param family: Nombre de la familia tipográfica.
        :param size: Tamaño de la fuente en puntos.
        """
        font = self.font()  # Obtiene la fuente actual del botón
        font.setBold(True) # Establecemos la fuente en negrita
        font.setFamily(family)  # Establece la familia de la fuente
        font.setPointSize(size)  # Establece el tamaño de la fuente
        self.setFont(font)  # Aplica la configuración de la fuente al botón


    # Método para actualizar el color de fondo del botón
    def updateBackgroundColor(self, color):
        """
        Actualiza el color de fondo del botón.
        :param color: Objeto QColor que representa el color de fondo.
        """
        palette = self.palette()  # Obtiene la paleta actual del botón
        palette.setColor(QPalette.Button, color)  # Configura el color de fondo del botón en la paleta
        self.setPalette(palette)  # Aplica la paleta actualizada al botón
        self.setAutoFillBackground(True)  # Permite que el botón rellene automáticamente su fondo



    #############
    ## EVENTOS ##
    #############
    """
    Eventos personalizados que modifican el comportamiento visual del botón y emiten señales cuando se produce interacción.
    """

    # Evento que detecta cuando el botón es presionado
    def mousePressEvent(self, event):
        """
        Cambia el color de fondo al pressed_color y emite la señal signal_presionado cuando el botón es presionado.
        :param event: Evento de presionar el botón.
        """
        self.signal_presionado.emit()  # Emite la señal personalizada de botón presionado
        super().mousePressEvent(event)  # Llama al método original de mousePressEvent de la clase base

