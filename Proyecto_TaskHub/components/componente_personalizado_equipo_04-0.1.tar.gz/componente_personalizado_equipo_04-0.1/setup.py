from setuptools import setup, find_packages

setup(
    name="componente_personalizado_equipo_04",
    version="0.1",
    description="Coponentes personalizados con PySide6",
    author="Equipo_04",
    author_email="Equipo_04@equipo04.com",
    packages=find_packages(),
    install_requires=[
        "PySide6"
    ],
    python_requires=">=3.6",
    include_package_data=True,  # Esto permite incluir archivos adicionales
)
